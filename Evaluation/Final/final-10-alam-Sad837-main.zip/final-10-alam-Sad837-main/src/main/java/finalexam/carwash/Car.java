package finalexam.carwash;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

class Car implements Runnable {
    //TODO: Your solution goes here
    private String carId;
    private int washTime;
    private CarWash carWash;
    private Random RNG;

    public Car(String carId, int washTime, CarWash carWash){
        this.carId = carId;
        this.washTime = washTime;
        this.carWash = carWash;


    }

    @Override
    public void run() {
        long start = TimeUnit.NANOSECONDS;
        System.out.println(
            
        "Car" + carId + "arrives" 

        );
    }

    public static void main(String[] args) {
        ExecutorService ex = Executors.newFixedThreadPool(0);
    }

}
