package finalexam.carwash;

import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CarWashMain {
    public static void main(String[] args) throws InterruptedException {
        ExecutorService ex = Executors.newCachedThreadPool();
        Random rnd = new Random();
        for(int i = 1; i<=5; i++){
            String id = "C" + i;
            Car car = new Car(id, rnd.nextInt(3), null);
            ex.submit(car);
            
        }

        Thread.sleep(100);
        System.out.println("The car wash is open");
        ex.shutdown();

        ex.awaitTermination(1000, TimeUnit.SECONDS);

        System.out.println("Car wash closed");


    }
}
