package finalexam.carwash;

import java.util.LinkedList;
import java.util.Random;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

class Car implements Runnable{

    private String carId;
    private int washTime;
    private CarWash carWash;
    // LinkedList queue;

    

    public Car(String carId, int washTime, CarWash carWash) {
        this.carId = carId;
        this.washTime = washTime;
        this.carWash = carWash;

    }



    @Override
    public void run() {
        while(true){
        CountDownLatch ready = new CountDownLatch(washTime);

        System.out.println("Car: " + carId + " arrives");

        // need countdwon latch 
        // try {
        //     Thread.sleep(100);
        // } catch (InterruptedException e) {
        //     e.printStackTrace();
        // }
        if(!carWash.hasBay()){
            System.out.println("Car "+ carId + "waiting for bay");
        }

    }

}
}
