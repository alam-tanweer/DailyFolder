package finalexam.carwash;

import java.util.Random;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

class Car implements Runnable{
    public String carId;
    public int washTime;
    public CarWash carWash;
    public CountDownLatch start;
    public Lock lock;
    public Condition condition;

    public Car(String carId, int washTime, CarWash carWash, CountDownLatch start, Lock lock, Condition condition){
        this.carId = carId;
        this.washTime = washTime;
        this.carWash = carWash;
        this.start = start;
        this.lock = lock;
        this.condition = condition;
    }

    public void run(){
        System.out.println("Car " + carId + " arrives");

        try {
            start.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        try{
            lock.lock();

            while(!carWash.hasBay()){
                System.out.println("Car " + carId + " waiting for bay");
                condition.await();
            }
            carWash.enter(carId);
            System.out.println("Car " + carId + " starts washing for " + washTime + " sec");
            Thread.sleep(washTime * 1000);
            System.out.println("Done");
            carWash.exit();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        finally{
            lock.unlock();
            condition.signal();
        }
        System.out.println("Car " + carId + " leaves");
    }
}
