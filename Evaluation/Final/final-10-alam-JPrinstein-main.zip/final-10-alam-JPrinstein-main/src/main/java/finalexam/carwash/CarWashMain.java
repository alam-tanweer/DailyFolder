package finalexam.carwash;

import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CarWashMain{

    
    public static void main(String[] args) throws InterruptedException {

        CarWash carWash = new CarWash(2);

        ExecutorService es = Executors.newCachedThreadPool();

        CountDownLatch start = new CountDownLatch(1);
        
        Lock lock = new ReentrantLock();
        Condition condition = lock.newCondition();

        Random random = new Random();

        for(int i = 0; i<3; i++){
            String name = "C" + i;
            System.out.println(name);
            Car car = new Car(name, random.nextInt(1, 4), carWash, start, lock, condition);
            es.submit(car);
        }

        start.countDown();

        System.out.println("Car wash is open!");

        es.awaitTermination(15, TimeUnit.MINUTES);
    }
}
