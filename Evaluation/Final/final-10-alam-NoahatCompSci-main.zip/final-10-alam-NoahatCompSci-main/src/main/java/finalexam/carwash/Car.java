package finalexam.carwash;

import java.util.Random;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

public class Car implements Runnable{
    private String carId;
    private int washTime;
    private static CarWash carWash = new CarWash(2);
    public static CountDownLatch latch = new CountDownLatch(1);
    private static Lock lock = new ReentrantLock();
    private static Condition condition = lock.newCondition();

    public Car(String carId, int washTime) {
        this.carId = carId;
        this.washTime = washTime;
    }

    @Override
    public void run() {
        try {
            System.out.println("Car "+carId+" arrives");
            latch.await();
            while(!carWash.hasBay()){
                condition.await();
            }
            lock.lock();
            carWash.enter(carId);
            System.out.println("Car "+carId+" starts washing for "+washTime+" seconds");
            Thread.sleep(washTime*1000);
            carWash.exit();
            lock.unlock();
        } catch (Exception e) {
            e.printStackTrace();
        } finally{
            System.out.println("Car "+carId+" leaves");
            if(!carWash.hasBay()) condition.signalAll();
        }
    }
    


}
