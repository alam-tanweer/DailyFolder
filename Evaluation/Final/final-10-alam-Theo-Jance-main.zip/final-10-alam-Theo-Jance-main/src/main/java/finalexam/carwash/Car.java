package finalexam.carwash;

import java.util.Random;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

class Car implements Runnable{
    private String carID;
    private int washTime;
    private static CarWash carWash;
    private CountDownLatch latch;
    private static ReentrantLock lock = new ReentrantLock();
    private static Condition condition = lock.newCondition();

    public Car(String carID, int washTime, CarWash carWash, CountDownLatch latch){
        this.carID = carID;
        this.washTime = washTime;
        this.carWash = carWash;
        this.latch = latch;
    }

    @Override
    public void run() {
        System.out.println("Car " + carID + " arrives");
        try{
            latch.await();
            lock.lock();
            if(carWash.hasBay()){
                carWash.enter(carID);
                System.out.println("Car " + carID + " starts washing for " + washTime + " seconds");
                Thread.sleep(washTime * 1000);
                System.out.println("Car " + carID + " leaves");
                carWash.exit();
                condition.signalAll();
            }else{
                System.out.println("Car " + carID + " waiting for bay");
                condition.awaitUninterruptibly();
            }
        }catch(InterruptedException e){
            e.printStackTrace();
        }finally{
            lock.unlock();
        }
    }

    public static void main(String[] args) throws InterruptedException{
        Random rand = new Random();
        CarWash carWash = new CarWash(2);
        ExecutorService exec = Executors.newCachedThreadPool();
        CountDownLatch latch = new CountDownLatch(5);
        for(int i = 0; i < 5; i++){
            int washTime = rand.nextInt(1,4);
            Car car = new Car("" + i, washTime, carWash, latch);
            latch.countDown();
            exec.submit(car);
        }
        exec.shutdown();

        System.out.println("Car wash is open!");
        exec.awaitTermination(1, TimeUnit.DAYS);
        System.out.println("Car wash is closed");
    }
    

}
