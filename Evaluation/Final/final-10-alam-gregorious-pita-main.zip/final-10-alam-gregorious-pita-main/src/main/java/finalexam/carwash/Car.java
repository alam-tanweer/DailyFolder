package finalexam.carwash;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

class Car implements Runnable {
    private String carId;
    private int washTime;
    private CarWash carWash;
    private CountDownLatch latch;
    private Lock washLock;
    private Condition washCondition;


    public Car(String carId, int washTime, CarWash carWash, CountDownLatch latch, Lock washLock, Condition washCondition) {
        this.carId = carId;
        this.washTime = washTime;
        this.carWash = carWash;
        this.latch = latch;
        this.washLock = washLock;
        this.washCondition = washCondition;
    }

    @Override
    public void run() {
        System.out.println("Car " + carId + " arrives");
        boolean washed = false;
        try {
            latch.await();
            while (!washed) {
                if (carWash.hasBay()) {
                    washLock.lock();
                    carWash.enter(carId);
                    System.out.println("Car " + carId + " starts washing for " + washTime + " sec");
                    Thread.sleep(washTime * 1000);
                    carWash.exit();
                    washed = true;
                    washCondition.signalAll();
                    System.out.println("Car " + carId + " leaves");
                }
                else {
                    System.out.println("Car " + carId + " waiting for bay");
                    washCondition.awaitUninterruptibly();
                }
            }
            
        }
        catch (Exception e) {System.out.println("Car error");}
        finally {washLock.unlock();}

    }
}
