package finalexam.carwash;

import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CarWashMain {
    public static void main(String[] args) throws InterruptedException {
        CarWash washer = new CarWash(2);
        CountDownLatch latch = new CountDownLatch(1);
        Lock lock = new ReentrantLock();
        Condition condition = lock.newCondition();
        ExecutorService exserv = Executors.newCachedThreadPool();

        Random rng = new Random();
        Car car1 = new Car("C1", rng.nextInt(1, 4), washer, latch, lock, condition);
        Car car2 = new Car("C2", rng.nextInt(1, 4), washer, latch, lock, condition);
        Car car3 = new Car("C3", rng.nextInt(1, 4), washer, latch, lock, condition);
        Car car4 = new Car("C4", rng.nextInt(1, 4), washer, latch, lock, condition);
        Car car5 = new Car("C5", rng.nextInt(1, 4), washer, latch, lock, condition);

        exserv.submit(car1);
        exserv.submit(car2);
        exserv.submit(car3);
        exserv.submit(car4);
        exserv.submit(car5);

        Thread.sleep(1000);
        latch.countDown();
        System.out.println("Car wash is open!");
        exserv.shutdown();
        exserv.awaitTermination(1, TimeUnit.MINUTES);
        System.out.println("Car wash is closed");
    }
}
