package finalexam.carwash;

import java.util.Random;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

class Car implements Runnable{
    private String carId;
    private int washTime;
    private CarWash carWash;
    private CountDownLatch latch;
    private Lock lock;
    private Condition condition;

    public Car(String carId, int washTime, CarWash carWash, CountDownLatch latch, Lock lock, Condition condition) {
        this.carId = carId;
        this.washTime = washTime;
        this.carWash = carWash;
        this.latch = latch;
        this.lock = lock;
        this.condition = condition;
    }

    public void run(){
        System.out.println("Car " + this.carId + " arrives");
        latch.countDown();
        lock.lock();
        try{

            while(!carWash.hasBay()){
                condition.await();
            }
            carWash.enter(carId);
            System.out.println("Car " + carId + " starts washing for " + washTime + " sec");
            lock.unlock();
            Thread.sleep(washTime*1000);
            lock.lock();
            carWash.exit();

            System.out.println("Car " + carId + " leaves");
            condition.signalAll();

        }catch(InterruptedException e){
            e.printStackTrace();
            }finally{
            lock.unlock();
        }

    }

}
