package finalexam.taskassignment;

import java.util.*;
import finalexam.backtracker.*;

public class TaskAssignment implements Configuration<TaskAssignment> {

    private List<Integer> remaining;
    private List<Integer> selected;
    private int target;

    public TaskAssignment(List<Integer> tasks, int target) {
        this.remaining = tasks;
        this.selected = new ArrayList<>();
        this.target = target;
    }

    private TaskAssignment(List<Integer> remaining, List<Integer> selected, int target) {
        this.remaining = remaining;
        this.selected = selected;
        this.target = target;
    }

    @Override
    public Collection<TaskAssignment> getSuccessors() {
        Collection<TaskAssignment> successors = new ArrayList<>();

        for (int i=0; i<remaining.size();i++){
            Integer value = remaining.get(i);
            List<Integer> newRemaining = new ArrayList<>(remaining);
            newRemaining.remove(i);

            List<Integer> newSelected = new ArrayList<>(selected);
            newSelected.add(value);
            successors.add(new TaskAssignment(newRemaining, newSelected, target));
        }

        return successors;
    }

    @Override
    public boolean isValid() {
        return sum(selected) <= target;
    }

    @Override
    public boolean isGoal() {
        return sum(selected) == target;
    }

    @Override
    public String toString() {
        return selected.toString();
    }

    //Utility method. You can use this method to sum numbers in the list.
    //Or Use your own implemnetation.
    private int sum(List<Integer> list) {
        return list.stream().mapToInt(Integer::intValue).sum();
    }

    public static void main(String[] args) {
        Backtracker<TaskAssignment> solver = new Backtracker<>(false);

        TaskAssignment t1 = new TaskAssignment(Arrays.asList(2,3,5,7), 10);
        TaskAssignment sol1 = solver.solve(t1);
        System.out.println("Tasks: [2,3,5,7], Target=10");
        System.out.println(sol1 != null ? "Solution: " + sol1 : "No solution found");

        TaskAssignment t2 = new TaskAssignment(Arrays.asList(2,4,6), 5);
        TaskAssignment sol2 = solver.solve(t2);
        System.out.println("\nTasks: [2,4,6], Target=5");
        System.out.println(sol2 != null ? "Solution: " + sol2 : "No solution found");
    }
}