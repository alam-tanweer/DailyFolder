package finalexam.carwash;

import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CarWashMain {
    public static void main(String[] args) throws InterruptedException {
        CarWash carWash = new CarWash(2);
        CountDownLatch latch = new CountDownLatch(5);
        Lock lock = new ReentrantLock();
        Condition condition = lock.newCondition();
        ExecutorService exec = Executors.newCachedThreadPool();
        Random rand = new Random();

        for (int i = 1; i<=5; i++){
            exec.submit(new Car("C"+i, rand.nextInt(1,4), carWash, latch, lock, condition));
        }
        System.out.println("Car wash is open!");
        exec.awaitTermination(9, TimeUnit.SECONDS);
        System.out.println("Car wash is closed");
        exec.shutdown();
    }
}
