package finalexam.carwash;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

class Car implements Runnable{
    public String carId;
    public int washTime;
    public CarWash carWash;
    public CountDownLatch cdl;
    public Lock lock;
    public Condition noneAvailable;
    public Car(String carId, int washTime, CarWash carWash, CountDownLatch cdl, Lock lock, Condition noneAvailable){
        this.carId = carId;
        this.washTime = washTime;
        this.carWash = carWash;
        this.cdl=cdl;
        this.lock = lock;
        this.noneAvailable = noneAvailable;
    }
    @Override
    public void run() {
        System.out.println("Car " + carId + " arrives");
        cdl.countDown();
        try {
            cdl.await();
        } catch (InterruptedException ex) {
            System.getLogger(Car.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
        lock.lock();
        try{
            while(!carWash.hasBay()){
                System.out.println("Car " + carId + " waiting for bay");
                noneAvailable.await();
            }
            carWash.enter(carId);
        } catch (Exception e){
            e.printStackTrace();
        } finally{
            lock.unlock();
        }
        System.out.println("Car " + carId + " starts washing for " + washTime + " sec");
        try {
            Thread.sleep(washTime * 1000);
        } catch (InterruptedException ex) {
            System.getLogger(Car.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
        lock.lock();
        try {
            carWash.exit();
            noneAvailable.signal();
        } catch (Exception e) {
            e.printStackTrace();
        } finally{
            lock.unlock();
        }
        System.out.println("Car " + carId + " leaves");
        // while(true){
        //     try{
        //         if(carWash.hasBay()){
        //             carWash.enter(carId);
                    
        //             carWash.exit();
        //             inUse.signal();
                    
        //             break;
        //         }
        //         else{
                    
        //         }
        //     } catch(Exception e){
        //         e.printStackTrace();
        //     } finally{
        //         lock.unlock();
        //     }
        // }
    }

}
