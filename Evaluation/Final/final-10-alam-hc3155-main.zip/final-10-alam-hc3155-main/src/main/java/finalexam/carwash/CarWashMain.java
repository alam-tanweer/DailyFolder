package finalexam.carwash;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CarWashMain {
    public static void main(String[] args) throws InterruptedException {
        CarWash cw = new CarWash(2);
        CountDownLatch cdl = new CountDownLatch(5);
        CountDownLatch start = new CountDownLatch(1);
        Random ran = new Random();
        Lock lock = new ReentrantLock();
        Condition noneAvailable = lock.newCondition();
        Car c1 = new Car("C1", ran.nextInt(1, 4), cw, cdl,lock,noneAvailable);
        Car c2 = new Car("C2", ran.nextInt(1, 4), cw, cdl,lock,noneAvailable);
        Car c3 = new Car("C3", ran.nextInt(1, 4), cw, cdl,lock,noneAvailable);
        Car c4 = new Car("C4", ran.nextInt(1, 4), cw, cdl,lock,noneAvailable);
        Car c5 = new Car("C5", ran.nextInt(1, 4), cw, cdl,lock,noneAvailable);
        List<Car> cars = new ArrayList<>();
        cars.add(c1);
        cars.add(c2);
        cars.add(c3);
        cars.add(c4);
        cars.add(c5);
        ExecutorService es = Executors.newCachedThreadPool();
        for(Car c : cars){
            es.submit(c);
        }
        cdl.await();
        es.shutdown();
        System.out.println("Car wash is open!");
        start.countDown();
        es.awaitTermination(1000, TimeUnit.HOURS);
        System.out.println("Car wash is closed");
    }
}
