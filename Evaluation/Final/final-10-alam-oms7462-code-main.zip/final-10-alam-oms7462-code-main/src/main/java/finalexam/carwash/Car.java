package finalexam.carwash;

import java.util.Random;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

class Car implements Runnable {
    private String carId;
    private int washTime;
    private CarWash carWash;

    

    int numCars = 5;
    public CountDownLatch latch = new CountDownLatch(numCars);
    Lock lock = new ReentrantLock();
    Condition condition = lock.newCondition();

    public Car(String carId, int washTime, CarWash carWash) {
        this.carId = carId;
        this.washTime = washTime;
        this.carWash = carWash;
    }

    @Override
    public void run() {
        System.out.println("Car " + carId + " arrives");

        
        latch.countDown();


        while (!(carWash.hasBay())) {
            System.out.println("Car " + carId + " waiting for bay");
            condition.awaitUninterruptibly();
        }

        try{
            lock.lock();
        
        carWash.enter(carId);
        System.out.println("Car " + carId + " starts washing for " + washTime + " sec");

        try {
            Thread.sleep(washTime * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    
        carWash.exit();
        condition.signalAll();
        System.out.println("Car " + carId + " leaves ");
        } finally {
        lock.unlock();
    }

    }


    public static void main(String[] args) {
        ExecutorService exs = Executors.newCachedThreadPool();

        CarWash carWash1 = new CarWash(2);
        CountDownLatch latch = new CountDownLatch(5);
        Lock lock = new ReentrantLock();
        Condition condition = lock.newCondition();
        Random rand = new Random();

        Car car1 = new Car("C1", rand.nextInt(1,4), carWash1);
        Car car2 = new Car("C2", rand.nextInt(1,4), carWash1);
        Car car3 = new Car("C3", rand.nextInt(1,4), carWash1);
        Car car4 = new Car("C4", rand.nextInt(1,4), carWash1);
        Car car5 = new Car("C5", rand.nextInt(1,4), carWash1);
        exs.submit(car1);
        exs.submit(car2);
        exs.submit(car3);
        exs.submit(car4);
        exs.submit(car5);

        
        System.out.println("Car wash is open!");

        try{
        exs.awaitTermination(1, TimeUnit.MINUTES);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
        System.out.println("Car wash is closed");

        

    }

}
