package finalexam.carwash;

public class CarWash {
    private int availableBays;

    public CarWash(int bays) {
        this.availableBays = bays;
    }

    /**
     * Return true if any bay is available
     * @return
     */
    public boolean hasBay() {
        return availableBays > 0;
    }

    /**
     * Method to indicate when a car enters the bay
     * This method will reduce the number of available bay by 1
     * @param carId
     */
    public void enter(String carId) {
        availableBays--;
    }

    /**
     * Method to indicate car has left the car wash
     * This method will increment the available bay by 1
     */
    public void exit() {
        availableBays++;
    }
}