package finalexam.carwash;

import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CarWashMain {
    public static void main(String[] args) throws InterruptedException {
        // create
        CarWash carWash = new CarWash(2);
        CountDownLatch latch = new CountDownLatch(2);
        Lock lock = new ReentrantLock();
        Condition condition = lock.newCondition();

        ExecutorService exec = Executors.newCachedThreadPool();

        // create 5 cars
        
        for (int i = 0; i < 5; i ++) {
            String carId = "C" + i;

            Random r = new Random();
            int washTime = r.nextInt(1,3);

            exec.submit(new Car(carId, washTime, carWash, latch, condition, lock));
            latch.countDown();
        }

        System.out.println("Car wash is open!");

        exec.awaitTermination(20, TimeUnit.SECONDS);

        System.out.println("Car wash is closed");
    }
}
