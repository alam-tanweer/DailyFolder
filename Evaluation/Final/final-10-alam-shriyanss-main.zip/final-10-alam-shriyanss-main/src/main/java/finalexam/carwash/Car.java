package finalexam.carwash;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

class Car extends Thread {

    private String carId;
    private int washTime; // seconds 
    private CarWash carWash;
    private CountDownLatch latch;
    private Condition condition;
    private Lock lock;

    public Car(String carId, int washTime, CarWash carWash, CountDownLatch latch, Condition condition, Lock lock) {
        this.carId = carId;
        this.washTime = washTime;
        this.carWash = carWash;
        this.latch = latch;
        this.condition = condition;
        this.lock = lock;
    }

    @Override
    public void run() {
        System.out.println("Car " + carId + " arrives");

        try {
            latch.await();

            // try to enter
            while (true) { // despite infinite loop, will only run twice max
                if (carWash.hasBay()) {
                    // enter
                    lock.lock();
                    carWash.enter(this.carId);

                    System.out.println("Car " + carId + " starts washing for " + washTime + " sec");

                    Thread.sleep(washTime * 1000);

                    carWash.exit();

                    lock.unlock();

                    condition.signalAll();

                    System.out.println("Car " + carId + " leaves");

                    // break after everything
                    break;
                } else {
                    // bay not available
                    System.out.println("Car " + carId + " waiting for the bay");

                    // wait using condition
                    condition.awaitUninterruptibly();
                }
            }

        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
