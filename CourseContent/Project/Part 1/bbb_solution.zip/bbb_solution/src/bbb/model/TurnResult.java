package bbb.model;

public class TurnResult {
    private final YardCoordinate playerCoordinate;
    private final DigResult playerResult;
    private final YardCoordinate cyberPupCoordinate;
    private final DigResult cyberPupResult;

    public TurnResult(YardCoordinate playerCoordinate, DigResult playerResult,
                      YardCoordinate cyberPupCoordinate, DigResult cyberPupResult) {
        this.playerCoordinate = playerCoordinate;
        this.playerResult = playerResult;
        this.cyberPupCoordinate = cyberPupCoordinate;
        this.cyberPupResult = cyberPupResult;
    }

    public YardCoordinate getPlayerCoordinate() {
        return playerCoordinate;
    }

    public DigResult getPlayerResult() {
        return playerResult;
    }

    public YardCoordinate getCyberPupCoordinate() {
        return cyberPupCoordinate;
    }

    public DigResult getCyberPupResult() {
        return cyberPupResult;
    }
}
