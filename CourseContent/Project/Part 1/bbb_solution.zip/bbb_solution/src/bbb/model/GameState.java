package bbb.model;

public enum GameState {
    IN_PROGRESS,
    PLAYER_WON,
    CYBERPUP_WON,
    PLAYER_QUIT
}
