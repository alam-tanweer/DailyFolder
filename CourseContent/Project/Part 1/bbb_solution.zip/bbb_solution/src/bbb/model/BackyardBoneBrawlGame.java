package bbb.model;

public interface BackyardBoneBrawlGame {
    TurnResult takeTurn(YardCoordinate coordinate);

    String getPlayerYard();

    String getCyberPupYard();

    GameState getGameState();

    void quit();
}
