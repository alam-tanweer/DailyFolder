package bbb.model;

public enum DigResult {
    TOY_PART,
    NOTHING,
    FULL_TOY,
    INVALID;

    @Override
    public String toString() {
        return switch (this) {
            case TOY_PART -> "Toy Part!";
            case NOTHING -> "Nothing!";
            case FULL_TOY -> "Final Toy Part!";
            case INVALID -> "Invalid!";
        };
    }
}
