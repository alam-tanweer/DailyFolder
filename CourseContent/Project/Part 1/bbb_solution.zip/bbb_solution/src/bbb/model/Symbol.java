package bbb.model;

/**
 * Encodes the visible state of a single yard coordinate.
 */
public enum Symbol {
    GRASS('#'),
    HOLE(' '),
    TOY_PART('@');

    private final char symbol;

    Symbol(char symbol) {
        this.symbol = symbol;
    }

    public char getSymbol() {
        return symbol;
    }
}
