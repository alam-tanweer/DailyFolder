package bbb.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class BackyardBoneBrawlGameImpl implements BackyardBoneBrawlGame {
    static final int SIZE = 10;

    private final Random random;
    private final Cell[][] playerYard;
    private final Cell[][] cyberPupYard;
    private final Set<YardCoordinate> playerDigs;
    private final Set<YardCoordinate> cyberPupDigs;
    private final Map<Toy, Integer> remainingPlayerToyParts;
    private final Map<Toy, Integer> remainingCyberToyParts;
    private GameState gameState;

    public BackyardBoneBrawlGameImpl() {
        this(new Random());
    }

    public BackyardBoneBrawlGameImpl(Random random) {
        this.random = random;
        this.playerYard = createEmptyYard();
        this.cyberPupYard = createEmptyYard();
        this.playerDigs = new HashSet<>();
        this.cyberPupDigs = new HashSet<>();
        this.remainingPlayerToyParts = new EnumMap<>(Toy.class);
        this.remainingCyberToyParts = new EnumMap<>(Toy.class);
        buryAllToys(playerYard, remainingPlayerToyParts);
        buryAllToys(cyberPupYard, remainingCyberToyParts);
        this.gameState = GameState.IN_PROGRESS;
    }

    @Override
    public TurnResult takeTurn(YardCoordinate coordinate) {
        if (gameState != GameState.IN_PROGRESS) {
            return new TurnResult(coordinate, DigResult.INVALID, null, null);
        }
        if (coordinate == null || !coordinate.isInBounds() || playerDigs.contains(coordinate)) {
            return new TurnResult(coordinate, DigResult.INVALID, null, null);
        }

        DigResult playerResult = dig(cyberPupYard, remainingCyberToyParts, coordinate, playerDigs);
        if (allToysFound(remainingCyberToyParts)) {
            gameState = GameState.PLAYER_WON;
            return new TurnResult(coordinate, playerResult, null, null);
        }

        YardCoordinate cyberCoordinate = randomUndugCoordinate(cyberPupDigs);
        DigResult cyberResult = dig(playerYard, remainingPlayerToyParts, cyberCoordinate, cyberPupDigs);
        if (allToysFound(remainingPlayerToyParts)) {
            gameState = GameState.CYBERPUP_WON;
        }

        return new TurnResult(coordinate, playerResult, cyberCoordinate, cyberResult);
    }

    @Override
    public String getPlayerYard() {
        return encodeYard(playerYard, false);
    }

    @Override
    public String getCyberPupYard() {
        return encodeYard(cyberPupYard, true);
    }

    @Override
    public GameState getGameState() {
        return gameState;
    }

    @Override
    public void quit() {
        if (gameState == GameState.IN_PROGRESS) {
            gameState = GameState.PLAYER_QUIT;
        }
    }

    private Cell[][] createEmptyYard() {
        Cell[][] yard = new Cell[SIZE][SIZE];
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                yard[r][c] = new Cell();
            }
        }
        return yard;
    }

    private void buryAllToys(Cell[][] yard, Map<Toy, Integer> remainingParts) {
        for (Toy toy : Toy.values()) {
            buryToy(yard, toy);
            remainingParts.put(toy, toy.getLength());
        }
    }

    private void buryToy(Cell[][] yard, Toy toy) {
        boolean placed = false;
        while (!placed) {
            boolean horizontal = random.nextBoolean();
            int row = random.nextInt(SIZE);
            int col = random.nextInt(SIZE);
            placed = canPlace(yard, toy, row, col, horizontal);
            if (placed) {
                for (int i = 0; i < toy.getLength(); i++) {
                    int targetRow = horizontal ? row : row + i;
                    int targetCol = horizontal ? col + i : col;
                    yard[targetRow][targetCol].toy = toy;
                }
            }
        }
    }

    private boolean canPlace(Cell[][] yard, Toy toy, int row, int col, boolean horizontal) {
        int endRow = horizontal ? row : row + toy.getLength() - 1;
        int endCol = horizontal ? col + toy.getLength() - 1 : col;
        if (endRow >= SIZE || endCol >= SIZE) {
            return false;
        }
        for (int i = 0; i < toy.getLength(); i++) {
            int targetRow = horizontal ? row : row + i;
            int targetCol = horizontal ? col + i : col;
            if (yard[targetRow][targetCol].toy != null) {
                return false;
            }
        }
        return true;
    }

    private DigResult dig(Cell[][] yard, Map<Toy, Integer> remainingParts,
                          YardCoordinate coordinate, Set<YardCoordinate> dugSet) {
        dugSet.add(coordinate);
        Cell cell = yard[coordinate.getRow()][coordinate.getColumn()];
        cell.dug = true;
        if (cell.toy == null) {
            return DigResult.NOTHING;
        }
        Toy toy = cell.toy;
        int left = remainingParts.get(toy) - 1;
        remainingParts.put(toy, left);
        return left == 0 ? DigResult.FULL_TOY : DigResult.TOY_PART;
    }

    private boolean allToysFound(Map<Toy, Integer> remainingParts) {
        return remainingParts.values().stream().allMatch(value -> value == 0);
    }

    private YardCoordinate randomUndugCoordinate(Set<YardCoordinate> dugSet) {
        List<YardCoordinate> candidates = new ArrayList<>();
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                YardCoordinate coordinate = new YardCoordinate(r, c);
                if (!dugSet.contains(coordinate)) {
                    candidates.add(coordinate);
                }
            }
        }
        Collections.shuffle(candidates, random);
        return candidates.get(0);
    }

    private String encodeYard(Cell[][] yard, boolean hideUndugToys) {
        StringBuilder builder = new StringBuilder();
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                Cell cell = yard[r][c];
                char ch;
                if (!cell.dug) {
                    ch = hideUndugToys || cell.toy == null ? Symbol.GRASS.getSymbol() : cell.toy.getSymbol();
                } else if (cell.toy == null) {
                    ch = Symbol.HOLE.getSymbol();
                } else {
                    ch = Symbol.TOY_PART.getSymbol();
                }
                builder.append(ch);
            }
            if (r < SIZE - 1) {
                builder.append(System.lineSeparator());
            }
        }
        return builder.toString();
    }

    private static class Cell {
        private Toy toy;
        private boolean dug;
    }
}
