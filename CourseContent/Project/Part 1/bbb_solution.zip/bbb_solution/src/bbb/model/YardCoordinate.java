package bbb.model;

import java.util.Locale;
import java.util.Objects;

public class YardCoordinate {
    public static final int SIZE = 10;

    private final int row;
    private final int column;

    public YardCoordinate(int row, int column) {
        this.row = row;
        this.column = column;
    }

    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }

    public boolean isInBounds() {
        return row >= 0 && row < SIZE && column >= 0 && column < SIZE;
    }

    public static YardCoordinate fromString(String text) {
        if (text == null) {
            return null;
        }
        String trimmed = text.trim().toUpperCase(Locale.ROOT);
        if (trimmed.length() < 2 || trimmed.length() > 3) {
            return null;
        }
        char rowChar = trimmed.charAt(0);
        if (rowChar < 'A' || rowChar > 'J') {
            return null;
        }
        String colText = trimmed.substring(1);
        if (!colText.chars().allMatch(Character::isDigit)) {
            return null;
        }
        int col = Integer.parseInt(colText);
        YardCoordinate coordinate = new YardCoordinate(rowChar - 'A', col);
        return coordinate.isInBounds() ? coordinate : null;
    }

    @Override
    public String toString() {
        return String.valueOf((char) ('A' + row)) + column;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof YardCoordinate coordinate)) {
            return false;
        }
        return row == coordinate.row && column == coordinate.column;
    }

    @Override
    public int hashCode() {
        return Objects.hash(row, column);
    }
}
