package bbb.model;

public enum Toy {
    BONE('B', 4),
    CHEW_TOY('C', 3),
    HOOP('H', 2),
    STICK('S', 3),
    BALL('O', 1);

    private final char symbol;
    private final int length;

    Toy(char symbol, int length) {
        this.symbol = symbol;
        this.length = length;
    }

    public char getSymbol() {
        return symbol;
    }

    public int getLength() {
        return length;
    }
}
