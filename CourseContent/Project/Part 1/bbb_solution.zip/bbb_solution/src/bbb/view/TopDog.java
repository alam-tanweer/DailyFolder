package bbb.view;

import bbb.model.BackyardBoneBrawlGame;
import bbb.model.DigResult;
import bbb.model.GameState;
import bbb.model.TurnResult;
import bbb.model.YardCoordinate;

import java.util.Scanner;

public class TopDog {
    private final BackyardBoneBrawlGame game;
    private final Scanner scanner;

    public TopDog(BackyardBoneBrawlGame game) {
        this.game = game;
        this.scanner = new Scanner(System.in);
    }

    public void play() {
        System.out.println("Welcome to Backyard Bone Brawl!");
        System.out.println("Can you dig it?\n");
        printBoards();

        while (game.getGameState() == GameState.IN_PROGRESS) {
            System.out.println("Enter dig coordinates (e.g. A5) or 'quit':");
            String input = scanner.nextLine().trim();

            if (input.equalsIgnoreCase("quit")) {
                game.quit();
                break;
            }

            YardCoordinate coordinate = YardCoordinate.fromString(input);
            TurnResult result = game.takeTurn(coordinate);
            if (result.getPlayerResult() == DigResult.INVALID) {
                System.out.println("Invalid coordinates. Please try again.\n");
                continue;
            }

            System.out.printf("You dug at %s: %s%n", result.getPlayerCoordinate(), result.getPlayerResult());
            if (game.getGameState() != GameState.PLAYER_WON && result.getCyberPupCoordinate() != null) {
                System.out.printf("CyberPup dug at %s: %s%n", result.getCyberPupCoordinate(), result.getCyberPupResult());
            }
            System.out.println();
            printBoards();
        }

        printGameOver();
    }

    private void printBoards() {
        System.out.println("CyberPup's Yard:");
        System.out.println(formatYard(game.getCyberPupYard(), true));
        System.out.println();
        System.out.println("Player's Yard:");
        System.out.println(formatYard(game.getPlayerYard(), false));
        System.out.println();
    }

    private String formatYard(String rawYard, boolean hideToys) {
        String[] rows = rawYard.split("\\R");
        StringBuilder builder = new StringBuilder("  0 1 2 3 4 5 6 7 8 9\n");
        for (int r = 0; r < rows.length; r++) {
            builder.append((char) ('A' + r)).append(' ');
            for (int c = 0; c < rows[r].length(); c++) {
                builder.append(colorize(rows[r].charAt(c), hideToys)).append(' ');
            }
            if (r < rows.length - 1) {
                builder.append('\n');
            }
        }
        return builder.toString();
    }

    private String colorize(char symbol, boolean hideToys) {
        return switch (symbol) {
            case '#' -> AnsiColorCodes.GREEN + "#" + AnsiColorCodes.RESET;
            case '@' -> AnsiColorCodes.YELLOW + "@" + AnsiColorCodes.RESET;
            case ' ' -> AnsiColorCodes.LT_GRAY + " " + AnsiColorCodes.RESET;
            case 'B' -> AnsiColorCodes.WHITE + "B" + AnsiColorCodes.RESET;
            case 'C' -> AnsiColorCodes.CYAN + "C" + AnsiColorCodes.RESET;
            case 'H' -> AnsiColorCodes.MAGENTA + "H" + AnsiColorCodes.RESET;
            case 'S' -> AnsiColorCodes.BROWN + "S" + AnsiColorCodes.RESET;
            case 'O' -> AnsiColorCodes.ORANGE + "O" + AnsiColorCodes.RESET;
            default -> hideToys ? String.valueOf(symbol) : String.valueOf(symbol);
        };
    }

    private void printGameOver() {
        System.out.println("Game Over!");
        switch (game.getGameState()) {
            case PLAYER_WON -> System.out.println("Hot diggity dog! You win!");
            case CYBERPUP_WON -> System.out.println("Ruh-roh! CyberPup wins!");
            case PLAYER_QUIT -> System.out.println("You quit the game.");
            default -> System.out.println("Thanks for playing!");
        }
    }
}
