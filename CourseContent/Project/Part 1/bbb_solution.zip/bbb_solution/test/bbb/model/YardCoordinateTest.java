package bbb.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class YardCoordinateTest {
    @Test
    void parsesValidCoordinate() {
        YardCoordinate coordinate = YardCoordinate.fromString("c7");
        assertNotNull(coordinate);
        assertEquals(2, coordinate.getRow());
        assertEquals(7, coordinate.getColumn());
        assertEquals("C7", coordinate.toString());
    }

    @Test
    void rejectsInvalidCoordinate() {
        assertNull(YardCoordinate.fromString("Z2"));
        assertNull(YardCoordinate.fromString("A10"));
        assertNull(YardCoordinate.fromString(""));
    }

    @Test
    void equalityWorks() {
        assertEquals(new YardCoordinate(1, 2), new YardCoordinate(1, 2));
        assertNotEquals(new YardCoordinate(1, 2), new YardCoordinate(2, 1));
    }
}
