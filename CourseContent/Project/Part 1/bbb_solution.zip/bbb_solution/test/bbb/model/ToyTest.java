package bbb.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ToyTest {
    @Test
    void toyMetadataIsAvailable() {
        assertEquals(4, Toy.BONE.getLength());
        assertEquals('C', Toy.CHEW_TOY.getSymbol());
    }
}
