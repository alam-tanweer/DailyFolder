package bbb.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DigResultTest {
    @Test
    void toStringMatchesPromptText() {
        assertEquals("Toy Part!", DigResult.TOY_PART.toString());
        assertEquals("Nothing!", DigResult.NOTHING.toString());
        assertEquals("Final Toy Part!", DigResult.FULL_TOY.toString());
    }
}
