package bbb.model;

import org.junit.jupiter.api.Test;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

class BackyardBoneBrawlGameImplTest {
    @Test
    void gameStartsInProgress() {
        BackyardBoneBrawlGameImpl game = new BackyardBoneBrawlGameImpl(new Random(7));
        assertEquals(GameState.IN_PROGRESS, game.getGameState());
    }

    @Test
    void invalidTurnRejected() {
        BackyardBoneBrawlGameImpl game = new BackyardBoneBrawlGameImpl(new Random(7));
        TurnResult result = game.takeTurn(null);
        assertEquals(DigResult.INVALID, result.getPlayerResult());
    }

    @Test
    void repeatDigRejected() {
        BackyardBoneBrawlGameImpl game = new BackyardBoneBrawlGameImpl(new Random(7));
        YardCoordinate coordinate = new YardCoordinate(0, 0);
        TurnResult first = game.takeTurn(coordinate);
        assertNotEquals(DigResult.INVALID, first.getPlayerResult());
        TurnResult second = game.takeTurn(coordinate);
        assertEquals(DigResult.INVALID, second.getPlayerResult());
    }

    @Test
    void playerAndCyberBoardsHaveTenRows() {
        BackyardBoneBrawlGameImpl game = new BackyardBoneBrawlGameImpl(new Random(7));
        assertEquals(10, game.getPlayerYard().split("\\R").length);
        assertEquals(10, game.getCyberPupYard().split("\\R").length);
    }

    @Test
    void quittingChangesState() {
        BackyardBoneBrawlGameImpl game = new BackyardBoneBrawlGameImpl(new Random(7));
        game.quit();
        assertEquals(GameState.PLAYER_QUIT, game.getGameState());
    }
}
