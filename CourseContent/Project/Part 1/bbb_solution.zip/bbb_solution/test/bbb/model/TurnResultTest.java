package bbb.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TurnResultTest {
    @Test
    void gettersReturnValues() {
        YardCoordinate player = new YardCoordinate(0, 0);
        YardCoordinate cyber = new YardCoordinate(1, 1);
        TurnResult result = new TurnResult(player, DigResult.TOY_PART, cyber, DigResult.NOTHING);

        assertEquals(player, result.getPlayerCoordinate());
        assertEquals(DigResult.TOY_PART, result.getPlayerResult());
        assertEquals(cyber, result.getCyberPupCoordinate());
        assertEquals(DigResult.NOTHING, result.getCyberPupResult());
    }
}
